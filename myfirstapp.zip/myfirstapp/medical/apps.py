from django.apps import AppConfig


class MedicalConfig(AppConfig):
    name = 'medical'
